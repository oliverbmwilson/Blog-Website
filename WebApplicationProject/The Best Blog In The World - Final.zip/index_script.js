function showLogin(showhide){
    if(showhide == true){
        document.getElementById("login_popup").style.visibility = "visible";
    }else if(showhide == false){
        document.getElementById("login_popup").style.visibility = "hidden"; 
    }
}

