function showEditPost(showhide){
    if(showhide == true){
        document.getElementById("edit_post_popup").style.visibility = "visible";
    }else if(showhide == false){
        document.getElementById("edit_post_popup").style.visibility = "hidden"; 
    }
}
